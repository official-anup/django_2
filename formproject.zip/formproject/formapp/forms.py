from django import forms
from .models import *

class MobileForm(forms.ModelForm):
              class Meta:
                    model=Phones
                    fields='__all__'