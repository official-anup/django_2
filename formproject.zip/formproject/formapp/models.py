from django.db import models

# Create your models here.
class Phones(models.Model):
    model   =models.CharField(max_length=100)
    brand   =models.CharField(max_length=100)
    ram     =models.IntegerField()
    storage =models.IntegerField()
    price   =models.IntegerField()
    
    def __str__(self):
        return self.brand+" "+self.model
    