# from urllib import request
from django.shortcuts import render
from .forms import *
# Create your views here.
def index_view(request):
    return render(request,'formapp/index.html')

def add_view(request):
    form=MobileForm()
    if request.method=='POST':
        print(request.POST)
        f=MobileForm(request.POST)
        f.save()
        
    return render(request,'formapp/add.html',{'form':form})
    # if request.method=='post':
    #     print(request.post)
    #     f=ModelForm(request.post)
    #     f.save()
    # return  render(request,'formapp/add.html')


