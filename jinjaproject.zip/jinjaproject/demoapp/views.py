from django.shortcuts import render

# Create your views here.

def display_view(request):
    data={
        'title':" Jinja project",
        's_data':[
            {'name':'Anup','salary':12300,'age':23},
            {'name':'Monti','salary':12300,'age':34},
            {'name':'Shakir','salary':12300,'age':23},
            {'name':'Pratiksha','salary':12300,'age':23},
            {'name':'Minti','salary':12300,'age':22},
            
            ]
         
        
    }
    
    return render(request,'demoapp/index.html',data)
    
