from django.contrib import admin
from django.urls import path
from demoapp import views

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)



urlpatterns = [
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
 
    path('home/',views.home),
    # path('home2',views.homepage),
    path('display/',views.display),
    path('add/',views.add),
    path('delete/<str:username>/',views.delete_data),
    path('update/<str:username>/',views.upd_st),
    path('hello/',views.hello ),
    #  path('index/',views.index_view),
    # path('input/',views.add_view),
    # path('display/',views.display_view),
    # path('update/<int:id>',views.update_data),
    # path('delete/<int:id>',views.delete_data),
    # path('update/<int:id>',views.upd_st),
    
    path('search/',views.search_data),
    # path('hello/',views.hello),  
    path("getUser/<username>",views.getUser),
    path("getUser2/<username>",views.getUser2),
    path("addUser2/",views.addUser2),
    path("updateUser2/",views.updateUser2),
    path("deleteUser2/<username>",views.deleteUser2),
    path("getalluser2/",views.getallusers2),
    
    
    
    
   
    
    
    
    
    
    
]