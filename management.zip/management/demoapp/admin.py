####################################
# anup-anup@gmail.com-Anup@0805
##################################
from django.contrib import admin
# from demoapp.models import details,
from demoapp.models import Userdata,Examportal
# Register your models here.
admin.site.register(Examportal)
admin.site.register(Userdata)
