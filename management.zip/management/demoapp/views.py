from multiprocessing import AuthenticationError
import traceback
from django.shortcuts import render,redirect
# from demoapp.models import details,
from demoapp.models import Userdata,Examportal
from rest_framework.response import Response
from rest_framework.decorators import api_view
from demoapp.serializers import UserdataSerializer 


from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication

# Create your views here.

#######################################################
# def homepage(request):
#     return render(request,'demoapp/register.html') 

# def savedata(request):
#     name=request.GET['name']
#     password=request.GET['password']
#     mobno=request.GET['mobno']
#     email=request.GET['email']
#     Examportal.objects.create(name=name,password=password,mobno=mobno,email=email)
#     return render(request,'demoapp/login.html',{'message':'Registration successfull,please login'})

########################  Rest API  ############################### 
@api_view(['GET','POST'])
def hello(request):
     return Response({"RollNo":1,"Name":"Anup Alone","marks":100})

@api_view(['GET'])
def getUser(request,username):
    usersfromdb=Userdata.objects.get(username=username)
    # userfromdb=>[username=pranit password=python mobno=2334444]
    response=Response({"username":usersfromdb.username,"password":usersfromdb.password,"mobno":usersfromdb.mobno})
    #response["Access-Control-Allow-Origin"]="http://localhost:4200"
    return response


@authentication_classes([AuthenticationError])
@permission_classes([IsAuthenticated])
@api_view(['GET'])
def getallusers2(request):
    usersfromdb=Userdata.objects.all()
    print(usersfromdb)
    serilizer=UserdataSerializer(usersfromdb,many=True)
    return Response(serilizer.data)
   

@api_view(['GET'])
def getUser2(request,username):
    usersfromdb=Userdata.objects.get(username=username)
    print(usersfromdb)
    serilizer=UserdataSerializer(usersfromdb) 
    # serilizalier converts object into python dictionary
    return Response(serilizer.data)
    #response["Access-Control-Allow-Origin"]="http://localhost:4200"
    
  

@api_view(['POST'])
def addUser2(request):
    serilizer=UserdataSerializer(data=request.data)
    if serilizer.is_valid():
        serilizer.save()
    return Response("Record added") 
    # return Response(serilizer.data) 
    

# response class convertes dict to json string

@api_view(['PUT'])
def updateUser2(request):
    userFromClient=request.data
    usersfromdb=Userdata.objects.get(username=userFromClient["username"])
    serilizer=UserdataSerializer(usersfromdb,data=userFromClient,partial=False)
    if serilizer.is_valid():
        serilizer.save()
    return Response("Record Updated:")    

@api_view(['DELETE'])
def deleteUser2(request,username):
    Userdata.objects.filter(username=username).delete()
    response=Response("record deleted: ")
    return response 
    
    

######################################################
def home(request):
    return render(request,'demoapp/home.html')

def add(request):
     print(request)
     if request.method=="POST":
          print(request.POST)
          n=request.POST.get('username')
          p=request.POST.get('password')
          m=request.POST.get('mobno')
          obj=Userdata(username=n,password=p,mobno=m)
          obj.save()
          return redirect('/demoapp/display/')
            
     return render(request,'demoapp/add.html')
 
# def add(request):
#     print(request)
#     if request.method=='POST':
#         print(request.POST)
#         name=request.POST.get('username')
#         pas=request.POST.get('password')
#         mob=request.POST.get('mobno')
#         s1=Userdata(username=name ,password=pas , mobno=mob)
#         s1.save()
#         print(f"Name of the emplayee is {name} ,password is {pas} and mobile number are {mob}")
        
#         # return HttpResponseRedirect('/Thank-you/')
#         return redirect('/display/')
    
#     return render(request,'demoapp/add.html')
 
 
def display(request):
     data=Userdata.objects.all()
     context={
          'data':data 
     }
     return render(request,'demoapp/display.html',context)


def delete_data(request,username):
    data=Userdata.objects.get(pk=username)
    context={'data':data}
    if request.method =='POST':
        data.delete()
        return redirect('/display/')
    return render(request,'demoapp/display.html',context)

def upd_st(request,username):
    
    data=Userdata.objects.get(pk=username)
    context={
        'data':data
    }
    if request.method == 'POST':
        
        n = request.POST.get('username')
        p = request.POST.get('password')
        m = request.POST.get('mobno')

        # s1 =Student.objects.get(roll=r)
        data.username=n
        data.password=p
        data.mobno=m
        data.save()
      
    return render(request,'demoapp/update.html',context)



# def del_st(request,id):
#     s1=Userdata.objects.get(pk=id)
#     context={
#         'data':s1
#     }
#     if request.method == 'POST':
#         # r = request.POST.get('roll')
#         # s1 =Student.objects.get(roll=r)
#         s1.delete()
#         return redirect('/display/')
      
    # return render(request, 'demoapp/delete.html',context)

def search_data(request):
    data=Userdata.objects.filter(marks__gt=70)
    
    context={'data':data}
    
    return render(request,'demoapp/search.html',context) 