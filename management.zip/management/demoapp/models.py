from django.db import models

# Create your models here.
# class details(models.Model):
#     name=models.CharField( max_length=200)
#     eid=models.IntegerField()
#     dept=models.CharField( max_length=200)
   
    
#     def __str__(self):
#         return self.name


class Userdata(models.Model):
     username=models.CharField(max_length=20,primary_key=True)
     password=models.CharField(max_length=20)
     mobno = models.IntegerField()

     #__str__() function gives us object data .

     def __str__(self):
          return "{},{},{}".format(self.username,self.password,self.mobno)

     class Meta:
          db_table="Userdata" 
          
          

class Examportal(models.Model):
     name=models.CharField(max_length=20,primary_key=True)
     password=models.CharField(max_length=20)
     mobno = models.IntegerField()
     email=models.CharField(max_length=100)
     

     #__str__() function gives us object data .

     def __str__(self):
          return "{},{},{},{}".format(self.name,self.password,self.mobno,self.email)

     class Meta:
          db_table="exam" 