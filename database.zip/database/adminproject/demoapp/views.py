from django.shortcuts import render

from demoapp import models

# Create your views here.
# class Student(models.Model):
#     name=models.CharField(ma)
