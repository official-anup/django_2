from django.shortcuts import render,redirect

from html1app.serializers import UserdataSerializer 
from .models import Student, Userdata
from rest_framework.response import Response
from rest_framework.decorators import api_view

def index_view(request):
    return render(request,'html1app/index.html')

def display_view(request):
    
    data=Student.objects.all()
    context={'data':data}
    return render(request,'html1app/display.html',context)       

def add_view(request):
    print(request)
    
    if request.method =='POST':
        print(request.POST)
        
        n=request.POST.get('name')
        r=request.POST.get('rollno')
        m=request.POST.get('marks')
        print(f'student name is {n} and roll no is {r} and marks are{m}')
        s1=Student(name=n,rollno=r,marks=m)
        s1.save()
        
        
        print(f'student name is {n} is added successfully')   
        
        return redirect('/display/')
    return render(request,'html1app/input.html')
   

def update_data(request,id):
    s1=Student.objects.get(pk=id)
    context={'data':s1}

    if request.method =='POST':
        n=request.POST.get('name')
        r=request.POST.get('rollno')
        m=request.POST.get('marks')
        print(f'student name is {n} and roll no is {r} and marks are{m}')
        #s1=Student(name=n,rollno=r,marks=m)
        s1.name= n
        s1.rollno=r
        s1.marks=m
        s1.save()
    
        return redirect('/display/')
    return render(request,'html1app/update.html',context)

def delete_data(request,id):
    s1=Student.objects.get(pk=id)
    context={'data':s1}
    if request.method =='POST':
        s1.delete()
        return redirect('/display/')
    return render(request,'html1app/delete.html',context)

def search_data(request):
    data=Student.objects.filter(marks__gt=70)
    
    context={'data':data}
    
    return render(request,'html1app/search.html',context)      

@api_view(['GET','POST'])
def hello(request):
    return Response({"RollNo":1,"Name":'Aboli',"Marks":80})
    

@api_view(['GET'])
def getUser(request,username):
    usersfromdb=Userdata.objects.get(username=username)
    # userfromdb=>[username=pranit password=python mobno=2334444]
    response=Response({"username":usersfromdb.username,"password":usersfromdb.password,"mobno":usersfromdb.mobno})
    #response["Access-Control-Allow-Origin"]="http://localhost:4200"
    return response

@api_view(['GET'])
def getUser2(request,username):
    usersfromdb=Userdata.objects.get(username=username)
    print(usersfromdb)
    serilizer=UserdataSerializer(usersfromdb) 
    # serilizalier converts object into python dictionary
    return Response(serilizer.data)
    #response["Access-Control-Allow-Origin"]="http://localhost:4200"    


        