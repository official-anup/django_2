from rest_framework import serializers
from html1app.models import Userdata

class UserdataSerializer(serializers.ModelSerializer):
    #username=serializers.CharField(max_length=20)
    #password=serializers.CharField(max_length=20)
    #mobno = serializers.IntegerField()

    class Meta:
        model=Userdata
        exclude=['password']
        #fields='__all__'