
from django.urls import path
from html1app import views

urlpatterns = [
    
    path('index/',views.index_view),
    path('input/',views.add_view),
    path('display/',views.display_view),
    path('update/<int:id>',views.update_data),
    path('delete/<int:id>',views.delete_data),
    path('search/',views.search_data),
    path('hello/',views.hello),
    path("getUser/<username>",views.getUser),
    path("getUser2/<username>",views.getUser2),


    
    ]

