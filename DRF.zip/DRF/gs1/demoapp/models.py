from django.db import models

# Create your models here.
class Students(models.Model):
    name=models.CharField(max_length=50)
    roll=models.IntegerField()
    city=models.CharField(max_length=50)
    
    # def __str__(self):
    #        return "{},{},{}".format(self.name,self.roll,self.city)
    
    # class meta:
    #     db_table="student"