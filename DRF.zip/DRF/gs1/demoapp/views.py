from django.http import HttpResponse
from django.shortcuts import render
from .models import Students
from .serializers import studentserializers
from rest_framework.renderers import JSONRenderer
# Create your views here.

def student_details(request):
    stu=Students.objects.get(id=1)
    serializer=studentserializers(stu)
    print(serializer.data)
    json_data=JSONRenderer().render(serializer.data)
    print(json_data)
    return HttpResponse(json_data,content_type="application/json")