from django.db import models

# Create your models here.
class Student(models.Model):
    name=models.CharField(max_length=100)
    
    # name=models.CharField(max_length=100,primary_key=True,) # This is when we want make primary key other than id
    roll=models.IntegerField()
    city=models.CharField(max_length=100)
    