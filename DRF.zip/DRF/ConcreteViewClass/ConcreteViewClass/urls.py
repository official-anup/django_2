
from django.contrib import admin
from django.urls import path
from demoapp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('list/',views.StudentList.as_view()),
    path('create/',views.StudentCreate.as_view()),
    path('list-create/',views.StudentListCreate.as_view()),
    path('get/<int:pk>',views.StudentGet.as_view()),
    path('update/<int:pk>',views.StudentUpdate.as_view()),
    path('delete/<int:pk>',views.StudentDestroy.as_view()),
    path('Retrive-Update/<int:pk>',views.StudentRetrieveUpdate.as_view()),
    path('Retrieve-Destroy/<int:pk>',views.StudentRetrieveDestroy.as_view()),
    path('Retrieve-Update-Destroy/<int:pk>',views.StudentRetrieveUpdateDestroy.as_view()),
    
    
    
]