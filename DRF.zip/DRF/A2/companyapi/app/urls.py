# 1)import :
from django.urls import path,include
from app import views
from rest_framework.routers import DefaultRouter

# 2)creating default router:
router=DefaultRouter()

# 3)Resgiter class with router.
router.register('com',views.CompanyViewSet,basename='company')
router.register('emp',views.EmployeeViewSet,basename='employee')


# 4)The API URLS are now determined automatically by the router:
urlpatterns=[
  path("",include(router.urls)),
 ]