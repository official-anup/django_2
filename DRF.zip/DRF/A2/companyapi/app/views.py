from django.shortcuts import render
from .models import Company,Employee
from .serializers import CompanySerializers,EmployeeSerializers
from rest_framework import viewsets
from rest_framework.decorators import action
# Create your views here.

class CompanyViewSet(viewsets.ModelViewSet):
   queryset=Company.objects.all()
   serializer_class = CompanySerializers 
   
   @action(detail=True,methods=["get"])
   def employee(self,request,pk=None):
      print("Get employee of ",pk,"company")

class EmployeeViewSet(viewsets.ModelViewSet):
   queryset=Employee.objects.all()
   serializer_class = EmployeeSerializers 