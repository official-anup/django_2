from django.db import models

# Create your models here.
type=(
    ("IT","IT"),
    ("Banking","Banking"),
    ("Travelling","Travelling"),
    ("Hardware","Hardware"),
    ("Education","Education"),
    
)

class Company(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    about=models.TextField()
    type=models.CharField(max_length=100,choices=type)
    date=models.DateTimeField(auto_now=True)
    active=models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.name} -- {self.location}"
    
# Employee model 

position=(
    ("manager","Manager"),
    ("sd","Software Developer"),
    ("pl","Project Leader"),
    ("hr","Human Resource"),
    
)

class Employee(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField(max_length=100)
    address=models.TextField()
    phone=models.IntegerField()
    position=models.CharField(max_length=100,choices=position)
    company=models.ForeignKey(Company,default=Company,on_delete=models.CASCADE)
    
    
    