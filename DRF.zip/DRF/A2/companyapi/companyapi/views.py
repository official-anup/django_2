from django.http import HttpResponse,JsonResponse


def home_page(request):
    print("home page requested.")
    # return HttpResponse("This is homepage.")
    city=["Pune","Nagpur","Mumbai","Hydrabad"]
    return JsonResponse(city,safe=False)