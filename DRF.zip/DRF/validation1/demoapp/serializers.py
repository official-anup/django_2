from rest_framework import serializers 
from .models import Student 

# validators:
def start_with_r(value):
     if value[0].lower()!="r":
          raise serializers.ValidationError("Name should start with the R.")
     
class StudentSerializers(serializers.Serializer):
    name=serializers.CharField(max_length=100,validators=[start_with_r])
    roll=serializers.IntegerField()
    city=serializers.CharField(max_length=100)
    
    def create(self,validate_data):
         return Student.objects.create(**validate_data)
     
     
    def update(self, instance, validated_data):
        instance.name = validated_data.get('name', instance.name)
        instance.roll = validated_data.get('roll', instance.roll)
        instance.city = validated_data.get('city', instance.city)
        instance.save()
        return instance
   # here instance is old data and validated data is new data
   
   # field level validation
   
    def validate_roll(self,value):
         if value>=200:
              raise serializers.ValidationError("seat full")
         return value
    
    def validate(self, data):
         nm=data.get("name")
         ct=data.get("city")
         if nm.lower()=="rohit" and ct.lower()!="pune":
              raise serializers.ValidationError("City must be pune.")
         return data
         