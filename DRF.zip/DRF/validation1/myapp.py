from django.shortcuts import render
import requests 
import json

URL=" http://127.0.0.1:8000/get/"

def get_data(id=None):
    data={}
    if id is not None:
        data={"id":id}
    json_data=json.dumps(data)
    r=requests.get(url=URL,data=json_data)
    data=r.json()
    print(data)
    return render(requests,'index.html',{'data':data})
# get_data(2)

def post_data(request):
    data={
        "name":"Rihan",
        "roll":2004,
        "city":"pune"
    }
    json_data=json.dumps(data)
    r=requests.post(url=URL,data=json_data)
    data=r.json()
    print(data)
post_data(requests)

def update_data(request):
    data={
        "id":4,
        "name":"Chaman",
         "roll":105,
        "city":"Walsara"
       
        
    }
    json_data=json.dumps(data)
    r=requests.put(url=URL,data=json_data)
    data=r.json()
    print(data)
# update_data(requests)

def delete_data(request):
    data={"id":2}
    json_data=json.dumps(data)
    r=requests.delete(url=URL,data=json_data)
    data=r.json()
    print(data)
# delete_data(requests)    
