from django.db import models

# Create your models here.
# {
# "f_name":"jay",
# "l_name":"baba",
# "username":"jayababa",
# "password":"jayababa@12345"
# }