
from django.contrib import admin
from django.urls import path,include
from accountApp.views import ResgisterView,LoginView
urlpatterns = [
   
    path('register/',ResgisterView.as_view() ),
    path('login/',LoginView.as_view() ),
    
    
]
