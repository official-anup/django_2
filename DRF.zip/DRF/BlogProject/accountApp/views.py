from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializer import LoginSerializer, RegisterSerializer
from rest_framework import status

# Create your views here.


class ResgisterView(APIView):
    def post(self,request):
        try:  
           data=request.data
           serializer=RegisterSerializer(data=data)
           if not serializer.is_valid():
            #    print(E)
               return Response({'data':serializer.errors,'msg':'something went wrong'},status=status.HTTP_400_BAD_REQUEST)
           
          
           serializer.save()
           return Response({'data':{},'msg':'Account is created.'},status=status.HTTP_201_CREATED)
        
        except Exception as e:  
            print(e)
            return Response({"data":{},"msg":"something went wrong"},status=status.HTTP_400_BAD_REQUEST)
        
        
class LoginView(APIView):
    def post(self,request):
        try:
            # print(e)
            data=request.data 
            serializer=LoginSerializer(data=data)
            if not serializer.is_valid():
            #    print(E)
               return Response({
                   'data':serializer.errors,
                   'msg':'something went wrong'
                   },status=status.HTTP_400_BAD_REQUEST)
           
            response=serializer.get_jwt_token(serializer.data)
            
            return response(response,status=status.HTTP_200_OK)
        
        except Exception as e: 
             print(e) 
             return Response({
                 'data':{},
                 'msg':'something went wrong'
                 },status=status.HTTP_400_BAD_REQUEST)
    