from rest_framework import serializers 
from demoapp.models import MyUser 

class UserregistrationSerializers(serializers.ModelSerializer):
    class Meta:
        model=MyUser 
        fields=["email","name","password","password2","tc"]