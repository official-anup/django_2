from django.shortcuts import render
import requests 
import json

URL=" http://127.0.0.1:8000/get/"

def get_data(id=None):
    data={}
    if id is not None:
        data={"id":id}
    json_data=json.dumps(data)
    r=requests.get(url=URL,data=json_data)
    data=r.json()
    print(data)
    # return render(requests,'index.html',{'data':data})
# get_data()

def post_data(request):
    data={
        "name":"Anup",
        "roll":104,
        "city":"Wagholi"
    }
    json_data=json.dumps(data)
    r=requests.post(url=URL,data=json_data)
    data=r.json()
    print(data)
post_data(requests)

def update_data(request):
    data={
        "id":8,
        "name":"Chaman",
         "roll":105,
        "city":"mul"
       
        
    }
    json_data=json.dumps(data)
    r=requests.put(url=URL,data=json_data)
    data=r.json()
    print(data)
# update_data(requests)

def delete_data(request):
    data={"id":1}
    json_data=json.dumps(data)
    r=requests.delete(url=URL,data=json_data)
    data=r.json()
    print(data)
# delete_data(requests)    
