from rest_framework import serializers 
from .models import Student 

"""
class StudentSerializer(serializers.ModelSerializer):
     class Meta:
          model=Student
          fields=["id","name","roll","city"]
"""
"""
class StudentSerializers(serializers.ModelSerializer):
#    name=serializers.CharField(read_only=True)
   class Meta:
       model=Student
       fields=["id","name","roll","city"]
     #   read_only_fields=["name","roll"]
       extra_kwargs={"name":{"read_only":True}}
"""
################# validation ###############################
class StudentSerializers(serializers.ModelSerializer):
  def start_with_r(value):
       if value[0].lower()!="r":
            raise serializers.ValidationError("Name should start with R.")
  name=serializers.CharField(validators=[start_with_r])
  
  class Meta:
       model=Student
       fields=["name","roll","city"]
   
   #field level validation:
  def validate_roll(self,value):
         if value>=200:
              raise serializers.ValidationError("seat full")
         return value

# object level 
  def validate(self, data):
         nm=data.get("name")
         ct=data.get("city")
         if nm.lower()=="rohit" and ct.lower()!="pune":
              raise serializers.ValidationError("City must be pune.")
         return data
       
# we dont need to do following steps like update and create which is coded at the last whn=en we used ModelSerializers:
""" 
class StudentSerializers(serializers.Serializer):
    name=serializers.CharField(max_length=100)
    roll=serializers.IntegerField()
    city=serializers.CharField(max_length=100)
    
    def create(self,validate_data):
         return Student.objects.create(**validate_data)
     
     
    def update(self, instance, validated_data):
        instance.name = validated_data.get('name', instance.name)
        instance.roll = validated_data.get('roll', instance.roll)
        instance.city = validated_data.get('city', instance.city)
        instance.save()
        return instance
   # here instance is old data and validated data is new data
"""