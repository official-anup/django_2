from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
# Create your views here.
# @api_view(["GET"])
# def hello(request):
#     return Response({"msg":"Hello world"})

# def hello(request):
#     if request.method=="POST":
#        print(request.data)
#     #    return Response(request.data)
#        return Response({"msg":"This is POST."})

   


@api_view(["GET","POST"])
def hello(request):
    if request.method=="GET":
        print(request.data)
        return Response({"msg":"This is get."})
    if request.method=="POST":
       print(request.data)
       return Response({"msg":"This is post.","data":request.data})