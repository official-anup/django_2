
from django.contrib import admin
from django.urls import path
from demoapp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('get-all/',views.hello),
    path('getOne-post-put-delete/<int:pk>',views.hello),
    
    ##############################################
    # path('getUser/<roll>',views.getUser),
    # path('getallusers2/',views.getallusers2),
    # path('getUser2/<roll>',views.getUser2),
    # path('addUser2/',views.addUser2),
    # path('updateUser2/',views.updateUser2),
    # path('deleteUser2/<roll>',views.deleteUser2),
   
    
    
]
