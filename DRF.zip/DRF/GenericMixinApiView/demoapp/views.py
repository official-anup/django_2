from .models import Student
from .serializers import StudentSerializer
from rest_framework.generics import GenericAPIView
from rest_framework.mixins import ListModelMixin
from rest_framework.mixins import CreateModelMixin
from rest_framework.mixins import RetrieveModelMixin
from rest_framework.mixins import UpdateModelMixin
from rest_framework.mixins import DestroyModelMixin

class StudentList(GenericAPIView,ListModelMixin):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
    
    def get(self,request,*args,**kwargs):
        return self.list(request,*args,**kwargs)
    # here get and list method have to write as it is..we cannot write other names
    

class StudentCreate(GenericAPIView,CreateModelMixin):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
    
    def post(self,request,*args,**kwargs):
          return self.create(request,*args,**kwargs)
    
class StudentRetrive(GenericAPIView,RetrieveModelMixin):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
    
    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)
    
    
class StudentUpdate(GenericAPIView,UpdateModelMixin):
    queryset=Student
    serializer_class=StudentSerializer
    
    def put(self,request,*args,**kwargs):
        return self.update(request,*args,**kwargs)
    
class StudentDelete(GenericAPIView,DestroyModelMixin):
    queryset=Student
    serializer_class=StudentSerializer
    
    def delete(self,request,*args,**kwargs):
        return self.destroy(request,*args,**kwargs)
    
##################### combine ###############################
class List_Create(GenericAPIView,ListModelMixin,CreateModelMixin):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
    
    def get(self,request,*args,**kwargs):
        return self.list(request,*args,**kwargs)
     
    def post(self,request,*args,**kwargs):
        return self.create(request,*args,**kwargs)

class Get_Update_Delete(GenericAPIView,RetrieveModelMixin,UpdateModelMixin,DestroyModelMixin):
    queryset=Student
    serializer_class=StudentSerializer
    
    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)
    
    def put(self,request,*args,**kwargs):
        return self.update(request,*args,**kwargs)

    def delete(self,request,*args,**kwargs):
        return self.destroy(request,*args,**kwargs)
"""    
from django.shortcuts import render
from rest_framework.decorators import api_view
# Create your views here.
from .models import Student
from rest_framework.response import Response
from .serializers import StudentSerializer

@api_view(['GET','POST','PUT','PATCH','DELETE'])
def hello(request,pk=None):
    if request.method=='GET':
        # id=request.data.get('id')
        id=pk
        if id  is not None:
            stu=Student.objects.get(id=id)
            serializer=StudentSerializer(stu)
            return Response(serializer.data)
        stu=Student.objects.all()
        serializer=StudentSerializer(stu,many=True)
        return Response(serializer.data)
        
    if request.method=='POST':
        serializer=StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg':'data created.'})
        return Response(serializer.errors)
    
    if request.method=="PUT":
        # id=request.data.get("id")
        id=pk
        stu=Student.objects.get(pk=id)
        serializer=StudentSerializer(stu,data=request.data,partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response({"msg":"Updated"})
        return Response(serializer.errors)
    
    if request.method=="PATCH":
        # id=request.data.get("id")
        id=pk
        stu=Student.objects.get(pk=id)
        serializer=StudentSerializer(stu,data=request.data,partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"msg":" patch data Updated"})
        return Response(serializer.errors)
    
    if request.method=="DELETE":
        # id=request.data.get("id")
        id=pk
        stu=Student.objects.get(pk=id)
        stu.delete()
        return Response({'msg':'data deleted.'})

#####################################################


# @api_view(['GET','POST'])
# def hello(request):
#      return Response({"name":"anup","roll":1,"city":"pune"})

# @api_view(['GET'])
# def getUser(request,roll):
#     usersfromdb=Student.objects.get(roll=roll)
#     # userfromdb=>[username=pranit password=python mobno=2334444]
#     response=Response({"name":usersfromdb.name,"roll":usersfromdb.roll,"city":usersfromdb.city})
#     #response["Access-Control-Allow-Origin"]="http://localhost:4200"
#     return response


# @api_view(['GET'])
# def getallusers2(request):
#     usersfromdb=Student.objects.all()
#     print(usersfromdb)
#     serilizer=Studentserializers(usersfromdb,many=True)
#     return Response(serilizer.data)
   

# @api_view(['GET'])
# def getUser2(request,roll):
#     usersfromdb=Student.objects.get(roll=roll)
#     print(usersfromdb)
#     serilizer=Studentserializers(usersfromdb) 
#     # serilizalier converts object into python dictionary
#     return Response(serilizer.data)
#     #response["Access-Control-Allow-Origin"]="http://localhost:4200"
    
  

# @api_view(['POST'])
# def addUser2(request):
#     serilizer=Studentserializers(data=request.data)
#     if serilizer.is_valid():
#         serilizer.save()
#     return Response("Record added") 
#     # return Response(serilizer.data) 
    

# # response class convertes dict to json string

# @api_view(['PUT'])
# def updateUser2(request):
#     userFromClient=request.data
#     usersfromdb=Student.objects.get(username=userFromClient["username"])
#     serilizer=Studentserializers(usersfromdb,data=userFromClient,partial=False)
#     if serilizer.is_valid():
#         serilizer.save()
#     return Response("Record Updated:")    

# @api_view(['DELETE'])
# def deleteUser2(request,username):
#     Student.objects.filter(username=username).delete()
#     response=Response("record deleted: ")
#     return response 

"""    
    
