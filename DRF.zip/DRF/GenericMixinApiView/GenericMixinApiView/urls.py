
from django.contrib import admin
from django.urls import path
from demoapp import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('list/',views.StudentList.as_view()),
    path('create/',views.StudentCreate.as_view()),
    path('get/<int:pk>',views.StudentRetrive.as_view()),
    path('update/<int:pk>',views.StudentUpdate.as_view()),
    path('delete/<int:pk>',views.StudentDelete.as_view()),
    
    ############### combine #####################################
    path('list-create/',views.List_Create.as_view()),
    # path('get-update-delete/<int:pk>',views.Get_Update_Delete.as_view()),
    
    path('get-update-delete/<str:pk>',views.Get_Update_Delete.as_view()) # This is when we want make primary key other than id
    
    
    # path('hello/<int:pk>',views.hello),
]