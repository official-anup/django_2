from .models import Student
from .serializers import StudentSerializer
from rest_framework import viewsets 
from rest_framework.authentication import SessionAuthentication
from rest_framework.permissions import IsAuthenticated
from .custompermissions import Mypermission
# to authenticate gloabally,then define or write in the setting file.

class StudentModelViewSet(viewsets.ModelViewSet):
    queryset=Student.objects.all()
    serializer_class=StudentSerializer
    authentication_classes=[SessionAuthentication]
    permission_classes=[Mypermission]
    
    
    
    
    # https://www.youtube.com/watch?v=r6bwPS5vMHA&t=1180s