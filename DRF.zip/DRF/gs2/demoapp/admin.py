"""
anup - anup@gmail.com - anup@12345    
"""

from django.contrib import admin
from demoapp.models import Students
# Register your models here.
admin.site.register(Students)
# Register your models here.
# class studentadmin(admin.ModelAdmin):
#     list_display=["id","name","roll","city"]