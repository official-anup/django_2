
################ SERIALIZATION
##################################
"""
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from .models import Students
from .serializers import studentserializers
from rest_framework.renderers import JSONRenderer
# Create your views here.

#For one data
# def student_details(request):
#     stu=Students.objects.get(id=1)
#     serializer=studentserializers(stu)
#     print(serializer.data)
#     json_data=JSONRenderer().render(serializer.data)
#     print(json_data)
#     return HttpResponse(json_data,content_type="application/json")


# With parameter 
# def student_details(request,pk):
#     stu=Students.objects.get(id=pk)
#     serializer=studentserializers(stu)
#     print(serializer.data)
#     json_data=JSONRenderer().render(serializer.data)
#     print(json_data)
#     return HttpResponse(json_data,content_type="application/json")


def student_details(request):
    stu=Students.objects.all()
    serializer=studentserializers(stu,many=True) # to python dict
    print(serializer)
    
    # json_data=JSONRenderer().render(serializer.data) # Into json
    # print(json_data)
    
    # return HttpResponse(json_data,content_type="application/json")
   
    # without writing above lines
    return JsonResponse(serializer.data,safe=False)  
"""

################ DE-SERIALIZATION
##################################
from django.shortcuts import render
import io
from rest_framework.parsers import JSONParser
from .serializers import studentserializers
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def student_create(request):
    if request.method=="POST":
        json_data=request.body
        stream=io.BytesIO(json_data)
        python_data=JSONParser().parse(stream) #json data to python 
        print(python_data)
        serializer=studentserializers(data=python_data) # into compex data type
        if serializer.is_valid():
            serializer.save()
            res={"msg":"data created"}
            json_data=JSONRenderer().render(res)
            return HttpResponse(json_data,content_type="application/json")
        
        json_data=JSONRenderer().render(serializer.errors)