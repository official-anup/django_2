
################ SERIALIZATION
##################################
"""
from django.contrib import admin
from django.urls import path
from demoapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('info/', views.student_details),
    # path('info/<int:pk>', views.student_details), 
]
"""


################ DE-SERIALIZATION
##################################
from django.contrib import admin
from django.urls import path
from demoapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('info_create', views.student_create), 
]