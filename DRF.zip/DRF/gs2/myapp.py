# THIS IS CLIENT APLLICATION #
#############################

################ SERIALIZATION
##################################
"""
import requests
URL="http://127.0.0.1:8000/info/"
r=requests.get(url=URL)

data=r.json()
print(data)
"""

################ DE-SERIALIZATION
##################################
import requests
import json
URL="http://127.0.0.1:8000/info_create/"
data={
    'name':'sonam',
    'roll':1,
    'city':'rajgad'
}

json_data=json.dumps(data) # into json
r=requests.post(url=URL,data=json_data)
data=r.json()
print(data)
