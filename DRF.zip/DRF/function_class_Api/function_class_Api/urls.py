
from django.contrib import admin
from django.urls import path,include
from demoapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
     path('get',views.hello),
    path('hello/',views.hello),
    
    
    #########################3
    # path('getUser/',views.getUser),
    # path('getallusers2/',views.getallusers2),
    # path('getUser2/',views.getUser2),
    # path('addUser2/',views.addUser2),
    # path('updateUser2/',views.updateUser2),
    # path('deleteUser2/',views.deleteUser2),
    
]
