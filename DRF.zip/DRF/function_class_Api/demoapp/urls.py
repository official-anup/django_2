from demoapp import views
from django.urls import path


