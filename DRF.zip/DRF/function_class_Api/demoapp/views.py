from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Student
from .serializers import Studentserializers
# Create your views here.






@api_view(["GET"])
def hello(request):
    return Response({"msg":"Hello world"})

# @api_view(["POST"])
# def hello(request):
#     if request.method=="POST":
#        print(request.data)
#        return Response({"msg":"This is post."})


# @api_view(["GET"])
# def hello(request):
#     if request.method=="GET":
#         print(request.data)
#         return Response({"msg":"This is post."})
#     if request.method=="POST":
#        print(request.data)
#        return Response({"msg":"This is post."})


#############################################

@api_view(['GET','POST'])
def hello(request):
     return Response({"name":"anup","roll":1,"city":"pune"})

@api_view(['GET'])
def getUser(request,roll):
    usersfromdb=Student.objects.get(roll=roll)
    # userfromdb=>[username=pranit password=python mobno=2334444]
    response=Response({"name":usersfromdb.name,"roll":usersfromdb.roll,"city":usersfromdb.city})
    #response["Access-Control-Allow-Origin"]="http://localhost:4200"
    return response


@api_view(['GET'])
def getallusers2(request):
    usersfromdb=Student.objects.all()
    print(usersfromdb)
    serilizer=Studentserializers(usersfromdb,many=True)
    return Response(serilizer.data)
   

@api_view(['GET'])
def getUser2(request,roll):
    usersfromdb=Student.objects.get(roll=roll)
    print(usersfromdb)
    serilizer=Studentserializers(usersfromdb) 
    # serilizalier converts object into python dictionary
    return Response(serilizer.data)
    #response["Access-Control-Allow-Origin"]="http://localhost:4200"
    
  

@api_view(['POST'])
def addUser2(request):
    serilizer=Studentserializers(data=request.data)
    if serilizer.is_valid():
        serilizer.save()
    return Response("Record added") 
    # return Response(serilizer.data) 
    

# response class convertes dict to json string

@api_view(['PUT'])
def updateUser2(request):
    userFromClient=request.data
    usersfromdb=Student.objects.get(username=userFromClient["roll"])
    serilizer=Studentserializers(usersfromdb,data=userFromClient,partial=False)
    if serilizer.is_valid():
        serilizer.save()
    return Response("Record Updated:")    

@api_view(['DELETE'])
def deleteUser2(request,roll):
    Student.objects.filter(roll=roll).delete()
    response=Response("record deleted: ")
    return response 