from django.shortcuts import render
import io
from rest_framework.parsers import JSONParser
from .serializers import StudentSerializers
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse,JsonResponse
from .models import Student
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def student_create(request):
    if request.method=="GET":
        json_data=request.body
        stream=io.BytesIO(json_data)
        python_data=JSONParser().parse(stream) #json data to python 
        print(python_data)
        id=python_data.get("id",None) # agr id me data h to chala jayega vrna none jayega
        if id is not None:
            stu=Student.objects.get(id=id)
            serializers=StudentSerializers(stu) # obejct into python dict
            json_data=JSONRenderer().render(serializers.data) # python dict data into json
            return HttpResponse(json_data,content_type='application/json')
    
        stu=Student.objects.all()
        serializers=StudentSerializers(stu,many=True)
        json_data=JSONRenderer().render(serializers.data)
        return HttpResponse(json_data,content_type='application/json')
    
    if request.method=="POST":
        json_data=request.body
        stream=io.BytesIO(json_data)
        python_data=JSONParser().parse(stream) #json data to python 
        print(python_data)
        serializer=StudentSerializers(data=python_data) # python into complex obejct
        if serializer.is_valid():
            serializer.save()
            res={'msg':"data inserted into database"}
            
            json_data=JSONRenderer().render(python_data)
            # we can write "res" in the place of "python data"
            return HttpResponse(json_data,content_type='application/json')
            
        json_data=JSONRenderer().render(serializer.errors)
        return HttpResponse(json_data,content_type='application/json')
    
    
    if request.method=="PUT":
        json_data=request.body
        stream=io.BytesIO(json_data)
        python_data=JSONParser().parse(stream) #json data to complex 
        id=python_data.get("id")
        stu=Student.objects.get(id=id)
        serializer = StudentSerializers(stu, data=python_data) #json data to python data 
        if serializer.is_valid():
            serializer.save()
            res={'msg':"data is updated"}
            
            json_data=JSONRenderer().render(res)
            # we can write "res" in the place of "python data"
            return HttpResponse(json_data,content_type='application/json')
            
        json_data=JSONRenderer().render(serializer.errors)
        return HttpResponse(json_data,content_type='application/json')
    
    
    if request.method=="DELETE":
        json_data=request.body 
        stream=io.BytesIO(json_data)
        python_data=JSONParser().parse(stream) #json data to python 
        id=python_data.get("id")
        stu=Student.objects.get(id=id)
        stu.delete()
        res={"msg":"Data is deleted."}
        # json_data=JSONRenderer().render(res)
        # return HttpResponse(json_data,content_type='application/json')
        return JsonResponse(res,safe=False)
    