from django.contrib import admin
from demoapp.models import Examportal
# Register your models here.
admin.site.register(Examportal)